package org.example.api;

import org.example.models.Deal;
import org.example.models.Item;

import java.util.List;

public interface DealService {
    Deal create(double discount, List<Item> productList);
    boolean endDeal(String dealId);
    Deal updateDeal(String dealId, List<Item> product);
    Deal updateDeal(String dealId, int updateDuration);
    Item claimDeal(String dealId, String itemId, String userId);
}
