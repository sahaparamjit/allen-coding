package org.example;

import org.example.api.DealService;
import org.example.impl.DealServiceImpl;
import org.example.models.Deal;
import org.example.models.Item;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        List<Item> list = Arrays.asList(
                Item.builder().itemId("1").description("Pen").maxAllowedInDeal(new AtomicInteger(2)).build(),
                Item.builder().itemId("2").description("Paper").maxAllowedInDeal(new AtomicInteger(5)).build(),
                Item.builder().itemId("3").description("Scissors").maxAllowedInDeal(new AtomicInteger(7)).build()
                );
        List<Item> updatedList = Arrays.asList(
                Item.builder().itemId("4").description("Tablet").maxAllowedInDeal(new AtomicInteger(1)).build(),
                Item.builder().itemId("5").description("Mobile").maxAllowedInDeal(new AtomicInteger(4)).build(),
                Item.builder().itemId("6").description("Watch").maxAllowedInDeal(new AtomicInteger(8)).build()
                );


        DealService dealService = new DealServiceImpl(list);
        Deal deal = dealService.create(10, list);

        dealService.updateDeal(deal.getDealId(), 3);
        dealService.updateDeal(deal.getDealId(), updatedList);

        dealService.claimDeal(deal.getDealId(), "4", "1");
        dealService.claimDeal(deal.getDealId(), "2", "1");

        //Different user
        dealService.claimDeal(deal.getDealId(), "2", "2");


        //TODO- Check for maxAllowed Time

        dealService.endDeal(deal.getDealId());
    }
}
