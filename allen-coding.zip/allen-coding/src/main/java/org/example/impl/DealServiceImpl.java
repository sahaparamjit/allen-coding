package org.example.impl;

import org.example.api.DealService;
import org.example.dao.DealDao;
import org.example.models.Deal;
import org.example.models.Item;

import java.time.LocalDateTime;
import java.time.temporal.ChronoField;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class DealServiceImpl implements DealService {

  DealDao dealDao = new DealDao();

  private static final int MAX_DEFAULT_DEAL_TIME = 2;

  public DealServiceImpl(List<Item> items) {
    dealDao.insertToItemsMap(items);
  }

  public boolean updateItemsDb(List<Item> items) {
    return dealDao.insertToItemsMap(items);
  }

  @Override
  public Deal create(double discount, List<Item> productList) {
    if (discount < 0 || productList.isEmpty()) {
      throw new RuntimeException("Price cannot be negative or Product list cannot be empty.");
    }
    int id = new Random().nextInt();
    Deal deal =
        Deal.builder()
            .dealId(String.valueOf(id))
            .description("Deal description-" + id)
            .discount(discount)
            .items(productList.stream().map(Item::getItemId).collect(Collectors.toSet()))
            .hours(MAX_DEFAULT_DEAL_TIME)
            .startTime(LocalDateTime.now().getLong(ChronoField.EPOCH_DAY))
            .build();
    if (dealDao.createDeal(deal)) {
      return deal;
    }
    throw new RuntimeException("Deal cannot be created!");
  }

  @Override
  public boolean endDeal(String dealId) {
    boolean dealEnded = false;
    Deal deal = dealDao.removeDeal(dealId);
    if (deal != null) dealEnded = true;
    return dealEnded;
  }

  @Override
  public Deal updateDeal(String dealId, List<Item> product) {
    Deal deal = dealDao.getDeal(dealId);
    dealDao.insertToItemsMap(product);
    if (deal != null) {
      deal.getItems().addAll(product.stream().map(Item::getItemId).collect(Collectors.toSet()));
    }
    return deal;
  }

  @Override
  public Deal updateDeal(String dealId, int updateDuration) {
    Deal deal = dealDao.getDeal(dealId);
    if (deal != null) {
      if (deal.getHours() < updateDuration) {
        throw new RuntimeException("Updated duration must be more than!" + deal.getHours());
      }
      deal.setHours(updateDuration);
    }
    return deal;
  }

  @Override
  public Item claimDeal(String dealId, String itemId, String userId) {
    return dealDao.claimDeal(dealId, itemId, userId);
  }
}
