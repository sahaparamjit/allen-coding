package org.example.dao;

import org.example.models.Deal;
import org.example.models.Item;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class DealDao {
    Map<String, Deal> mapOfDeal = new ConcurrentHashMap<>();
    Map<String, Set<String>> mapOfUserWithDeal = new ConcurrentHashMap<>();
    Map<String, Item> mapOfItems = new ConcurrentHashMap<>();

    public boolean insertToItemsMap(List<Item> itemList) {
        itemList.forEach(it -> mapOfItems.put(it.getItemId(), it));
        return true;
    }

    public boolean createDeal(Deal deal) {
        if (deal.getDealId() == null || deal.getDealId().isEmpty()) {
            throw new RuntimeException("dealId Cannot be an empty or null id!");
        }
        mapOfDeal.put(deal.getDealId(), deal);
        return true;
    }

    public Deal getDeal(String dealId) {
        if (dealId == null || dealId.isEmpty()) throw new RuntimeException("dealId Cannot be an empty or null id!");
        return mapOfDeal.get(dealId);
    }

    public Deal removeDeal(String dealId) {
        if (dealId == null || dealId.isEmpty()) throw new RuntimeException("dealId Cannot be an empty or null id!");
        Deal deal = null;
        if (mapOfDeal.containsKey(dealId)) {
            deal = mapOfDeal.remove(dealId);
        }
        return deal;
    }

    public boolean updateDeal(String dealId, int hours) {
        if (dealId == null || dealId.isEmpty()) throw new RuntimeException("dealId Cannot be an empty or null id!");
        Deal deal = mapOfDeal.get(dealId);
        if (deal == null) throw new RuntimeException("Deal is unavailable or removed");
        deal.setHours(hours);
        return true;
    }

    public Deal updateDeal(String dealId, Deal deal) {
        if (dealId == null || dealId.isEmpty()) throw new RuntimeException("dealId Cannot be an empty or null id!");
        Deal updatedDeal = null;
        if (mapOfDeal.containsKey(dealId)) {
            updatedDeal = mapOfDeal.put(dealId, deal);
        }
        return updatedDeal;
    }

    public Item claimDeal(String dealId, String itemId, String userId) {
        if (dealId == null || dealId.isEmpty()) throw new RuntimeException("dealId cannot be an empty or null id!");
        if (itemId == null || itemId.isEmpty()) throw new RuntimeException("itemId cannot be an empty or null id!");
        if (userId == null || userId.isEmpty()) throw new RuntimeException(" userId cannot be an empty or null id!");
        Deal deal = mapOfDeal.get(dealId);
        Item item = null;
        Set<String> userIds = mapOfUserWithDeal.getOrDefault(dealId, new HashSet<>());

        boolean itemExistsInDeal = deal.getItems().contains(itemId);
        boolean userAlreadyClaimed = userIds.contains(userId);
        boolean maxTimeAlowedWithinLimits = true;
        if (!userAlreadyClaimed && itemExistsInDeal) {
            item = mapOfItems.get(itemId);
            maxTimeAlowedWithinLimits = checkMaxTime(item);
            if (maxTimeAlowedWithinLimits && item.getMaxAllowedInDeal().get() > 0) {
                item.getMaxAllowedInDeal().decrementAndGet();
                mapOfUserWithDeal.computeIfAbsent(dealId, k -> new HashSet<>()).add(userId);
            } else if (maxTimeAlowedWithinLimits) {
                throw new RuntimeException("Item cannot be claimed as deal is expired!");
            }
        } else {
            if (userAlreadyClaimed)
                throw new RuntimeException("User has already claimed a deal");
            throw new RuntimeException("Item not part of the deal");
        }

        return item;
    }

    private boolean checkMaxTime(Item item) {
        /*
         * TODO - This is an incomplete method.
         * checking if deal startime+duration > currentTimeNow
         * then we will allow to add the item
         *
         * */
        return true;
    }
}
