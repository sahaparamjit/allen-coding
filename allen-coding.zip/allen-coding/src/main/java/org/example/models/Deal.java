package org.example.models;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Set;
import java.util.HashSet;

@Builder
@Getter
@Setter
@ToString
public class Deal {
    private String name;
    private String description;
    private int hours;
    private long startTime;
    private String dealId;
    private double discount;
    Set<String> items = new HashSet<>();
}
