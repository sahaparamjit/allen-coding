package org.example.models;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.concurrent.atomic.AtomicInteger;

@Builder
@Getter
@ToString
public class Item {
    private String itemId;
    private String name;
    private String description;
    private AtomicInteger maxAllowedInDeal;
}
